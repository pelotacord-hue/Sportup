SPORTUP — PROJETO ANDROID

Este pacote é um projeto Android Studio que envolve a primeira versão do SportUp em um aplicativo Android (WebView). Ele ainda não é o APK compilado.

COMO GERAR O APK NO ANDROID STUDIO

1. Instale o Android Studio no computador.
2. Extraia o arquivo ZIP.
3. No Android Studio, escolha Open e selecione a pasta SportUp-Android.
4. Aguarde a sincronização do Gradle. Se solicitado, aceite instalar Android SDK Platform 35 e Build Tools.
5. No menu, escolha Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Quando terminar, clique em locate. O APK de teste estará em:
   app/build/outputs/apk/debug/app-debug.apk
7. Transfira esse APK para o celular Android e abra-o para instalar. Talvez seja necessário permitir a instalação de apps desta origem nas configurações do Android.

REQUISITOS
- Android Studio recente
- JDK 17 (normalmente incluído no Android Studio)
- Android SDK Platform 35 (instalado pelo SDK Manager)

O QUE O APP JÁ TEM
- Futebol, basquete e handebol
- Lista de exercícios com marcação de conclusão
- Alimentação com sugestões gerais
- Registro de água
- Cronômetro de descanso
- Meta semanal e progresso local

OBSERVAÇÕES
- O projeto precisa ser compilado no Android Studio para gerar o APK.
- Os dados ficam salvos localmente no aparelho, dentro dos dados do app.
- Não há conta, sincronização em nuvem nem notificações nesta versão.
- As sugestões de alimentação são gerais, não uma dieta individual.
